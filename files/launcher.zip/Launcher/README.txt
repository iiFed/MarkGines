IF YOU ARE JUST UPDATING THIS DO NOT REPLACE "data.txt" or your gonna loose all your data!
dont touch it either bc you might break it and u have to download it again :(